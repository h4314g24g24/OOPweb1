﻿using Microsoft.AspNetCore.Mvc;
using oopveb8.Models;
using System.Collections.Generic;
using System.Linq;
using oopveb8.Models;

namespace oopveb8.Controllers
{
    public class UserController : Controller
    {
        private static List<User> users = new List<User>
        {
            new User { Id = 1, FirstName = "John", LastName = "Doe", Email = "john.doe@example.com", RegistrationDate = DateTime.Now },
            new User { Id = 2, FirstName = "Jane", LastName = "Doe", Email = "jane.doe@example.com", RegistrationDate = DateTime.Now }
        };

        public IActionResult Index()
        {
            return View(users);
        }

        public IActionResult Details(int id)
        {
            var user = users.FirstOrDefault(u => u.Id == id);
            if (user == null)
            {
                return NotFound();
            }
            return View(user);
        }
        [HttpGet]
        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Create(User user)
        {
            user.Id = users.Count + 1;
            user.RegistrationDate = DateTime.Now;
            users.Add(user);
            return RedirectToAction("Index");
        }

    }
}
